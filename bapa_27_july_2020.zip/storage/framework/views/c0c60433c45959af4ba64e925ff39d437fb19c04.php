
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="site-content" id="content">

    <div class="utilityMenu inner_banner">
        <div class="container text-center">
            <div style=" padding: 20px;font-size: 25px;">   <?php echo e($welcome_message); ?>

            </div>

        </div>
    </div>


    <div class="container-fluid">

        <?php echo $__env->yieldContent('main'); ?>

    </div>



</div><!-- #content -->


<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH F:\xampp\htdocs\bapa\resources\views/front/front_inner_layout.blade.php ENDPATH**/ ?>
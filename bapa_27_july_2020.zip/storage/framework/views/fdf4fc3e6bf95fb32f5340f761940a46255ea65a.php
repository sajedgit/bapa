

<?php $__env->startSection('main'); ?>



<div align="center">
     <br/> <br/> <br/> <br/> <br/>
	<h2>Welcome to Columbia Association</h2>
</div>

  

<?php $__env->stopSection(); ?>



	


<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\columbia_association\resources\views/welcome.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(__('memories.page_title')); ?></h1>
    <p class="mb-4"><?php echo e(__('memories.welcome_msg')); ?></p>

    <div align="right">
        <a href="<?php echo e(route('memories.index')); ?>" class="btn btn-default">Back</a>
    </div>
    <br/>


    <?php echo e(Form::open([ 'method'  => 'post','class'  => 'col-sm-6','files'=>'true', 'route' => [ 'memories.update', $data->id ] ])); ?>


    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>



    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('memories_name', (Lang::get('memories.enter_msg').' '.Lang::get('memories.memories_name')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('memories_name', $value = $data->memories_name ,array('class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('memories_details', (Lang::get('memories.enter_msg').' '.Lang::get('memories.memories_details')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::textarea('memories_details', $value = $data->memories_details ,array('rows'=>'4','class' => 'form-control'))); ?>

        </div>
    </div>


    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('memories_thumb', (Lang::get('memories.upload_msg').' '.Lang::get('memories.memories_thumb')),array('class'=>'control-label'))); ?>

        </div>

        <div class="col-sm-8">
            <?php echo e(Form::file('memories_thumb', array('class' => 'form-control'))); ?>

            <img src="<?php echo e(asset($data->memories_thumb)); ?>" class="img-thumbnail" width="100" />
            <input type="hidden" name="hidden_image" value="<?php echo e($data->memories_thumb); ?>" />

        </div>
    </div>





    <br/>



    <div class="form-group">
        <label class="control-label ">&nbsp;&nbsp;</label>
        <?php echo e(Form::submit(Lang::get('memories.update_btn_msg'), array('class' => 'btn btn-primary'))); ?>

    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\columbia_association\resources\views/Memory/edit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800"><?php echo e(__('board_members_categories.page_title')); ?></h1>
<p class="mb-4"><?php echo e(__('board_members_categories.welcome_msg')); ?></p>


 <div align="right">
  <a href="<?php echo e(route('board_members_categories.index')); ?>" class="btn btn-default">Back</a>
 </div>
 <br />
 
 <table class="table table-striped">
        <thead >
        <tr class="info">

            <th scope="col">Column</th>
            <th scope="col">Value</th>
        </tr>
        </thead>
        <tbody>
		<tr>
			<td><?php echo e(__('board_members_categories.board_members_category_name')); ?>

 			<td><?php echo e($data->board_members_category_name); ?> </td>
 
		</tr>
		<tr>
			<td><?php echo e(__('board_members_categories.board_members_category_position')); ?>

 			<td><?php echo e($data->board_members_category_position); ?> </td>
 
		</tr>
		<tr>
			<td><?php echo e(__('board_members_categories.board_members_category_active')); ?>

 			<td><?php echo e($data->board_members_category_active); ?> </td>
 
		</tr>
		</tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bapa\resources\views/BoardMembersCategory/view.blade.php ENDPATH**/ ?>
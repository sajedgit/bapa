



<?php $__env->startSection('main'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800"><?php echo e(__('events.page_title')); ?></h1>
<p class="mb-4"><?php echo e(__('events.welcome_msg')); ?></p>

<div align="right">
	<a href="<?php echo e(route('events.create')); ?>" class="btn btn-success btn-sm"><?php echo e(__('events.create')); ?></a>
</div>
<br />
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
	<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


	 <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('events.page_name')); ?></h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                        <th><?php echo e(__('events.event_title')); ?></th>

						 <th><?php echo e(__('events.event_venue')); ?></th>
						 <th><?php echo e(__('events.event_flyer_location')); ?></th>

						 <th><?php echo e(__('events.event_starting_date')); ?></th>



						 <th><?php echo e(__('events.event_ticket_price')); ?></th>
						 <th><?php echo e(__('events.event_total_seat')); ?></th>
						 <th><?php echo e(__('events.event_active')); ?></th>



                      <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                       <th><?php echo e(__('events.event_title')); ?></th>

						 <th><?php echo e(__('events.event_venue')); ?></th>
						 <th><?php echo e(__('events.event_flyer_location')); ?></th>

						 <th><?php echo e(__('events.event_starting_date')); ?></th>



						 <th><?php echo e(__('events.event_ticket_price')); ?></th>
						 <th><?php echo e(__('events.event_total_seat')); ?></th>
						 <th><?php echo e(__('events.event_active')); ?></th>



                      <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
				   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

					    <td><?php echo e($row->event_title); ?></td>

						 <td><?php echo e($row->event_venue); ?></td>
						 <td><img width="50" src="<?php echo e(asset($row->event_flyer_location)); ?>"></td>

						 <td><?php echo e($row->event_starting_date); ?></td>



						 <td><?php echo e($row->event_ticket_price); ?></td>
						 <td><?php echo e($row->event_total_seat); ?></td>
						 <td><?php echo e($row->event_active); ?></td>




                       <td class="text-center">
					  <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'events.destroy', $row->id ] ])); ?>


							<a href="<?php echo e(route('events.show', $row->id)); ?>" class="btn btn-primary">Show</a>
							<a href="<?php echo e(route('events.edit', $row->id)); ?>" class="btn btn-warning">Edit</a>
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<button type="submit"  onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger">Delete</button>
					  <?php echo e(Form::close()); ?>


					   </td>

                    </tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
                </table>
              </div>
            </div>
          </div>

		 </div>
        <!-- /.container-fluid -->


<?php echo $data->links(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\columbia_association\resources\views/Event/index.blade.php ENDPATH**/ ?>
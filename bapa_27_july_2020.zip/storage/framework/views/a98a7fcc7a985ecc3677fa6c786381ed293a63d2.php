

<?php $__env->startSection('main'); ?>



    <div align="center">
        <br/> <br/> <br/> <br/> <br/>
        <h2>Welcome to Bangladeshi American Police Association</h2>
    </div>



<?php $__env->stopSection(); ?>






<?php echo $__env->make('front/front_home_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bapa\resources\views/front/front_home.blade.php ENDPATH**/ ?>
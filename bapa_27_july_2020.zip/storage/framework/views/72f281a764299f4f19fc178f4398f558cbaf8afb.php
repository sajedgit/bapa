

<?php $__env->startSection('main'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(__('products.page_title')); ?></h1>
    <p class="mb-4"><?php echo e(__('products.welcome_msg')); ?></p>


    <div align="right">
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-default">Back</a>
    </div>


    <?php echo e(Form::open([ 'method'  => 'post','class'  => 'col-sm-6','files'=>'true', 'route' => [ 'products.store' ]  ])); ?>


    <?php echo csrf_field(); ?>


    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('product_name', (Lang::get('products.enter_msg').' '.Lang::get('products.product_name')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('product_name', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('products.product_name')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('product_description', (Lang::get('products.enter_msg').' '.Lang::get('products.product_description')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::textArea('product_description', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('products.product_description')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('price', (Lang::get('products.enter_msg').' '.Lang::get('products.price')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('price', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('products.price')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('stock', (Lang::get('products.enter_msg').' '.Lang::get('products.stock')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('stock', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('products.stock')))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('product_photo', (Lang::get('products.enter_msg').' '.Lang::get('products.photo')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::file('product_photo',array('class'=>'form-control'))); ?>

        </div>
    </div>



    <br/>


    <div class="form-group text-center">
        <?php echo e(Form::submit(Lang::get('products.submit_btn_msg'), array('class' => 'btn btn-primary'))); ?>


    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>



	


<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\columbia_association\resources\views/Product/create.blade.php ENDPATH**/ ?>
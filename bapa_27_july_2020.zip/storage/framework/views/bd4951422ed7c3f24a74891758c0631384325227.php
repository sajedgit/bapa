

<?php $__env->startSection('main'); ?>




    <br>


    <div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-3">
            <img class="img-responsive" src="<?php echo e(URL::to('/public/images/')."/".$board_members[0]->board_members_image_location); ?>">
        </div>
        <div class="col-xs-12 col-sm-9">
            <div class="row">
                <div class="col-sm-6">
                    <h2><?php echo e($board_members[0]->board_members_first_name." ".$board_members[0]->board_members_last_name); ?> </h2>
                   
                </div>

            </div>
        </div>
        <p>   <?php echo e($board_members[0]->bio); ?></p>
        <div class="col-xs-12">
            <hr />
        </div>
    </div>
    </div>


<?php $__env->stopSection(); ?>






<?php echo $__env->make('front/front_inner_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bapa\resources\views/front/front_board_member_details.blade.php ENDPATH**/ ?>

    @include('partials.header')



    <div class="site-content" id="content">


        @include('partials.modal')

        @include('partials.banner')

        @include('partials.messages')



    </div><!-- #content -->


    @include('partials.footer')


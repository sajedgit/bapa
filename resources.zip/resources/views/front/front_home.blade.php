@extends('front/front_home_layout')

@section('main')



    <div align="center">
        <br/> <br/> <br/> <br/> <br/>
        <h2>Welcome to Bangladeshi American Police Association</h2>
    </div>



@endsection






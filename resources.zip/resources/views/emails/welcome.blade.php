Hey {{$name}}, Welcome to our website. <br>
Please click <a href="{!! url('/verify', ['code'=>'sajed']) !!}"> Here</a> to confirm email
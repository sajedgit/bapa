<footer class="site-footer" id="colophon" role="contentinfo">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-4 col-md-4">
                <div class="footerInfo">
                    <h5>Bangladeshi American Police Association</h5>
                    <p>26 Thomas Street<br>New York, NY 10007</p>


                </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
                <div class="footerNews">

                    <p><a href="tel:2125871000">(212) 587-1000</a> Executive Office<br><a href="tel:2125879120">(212)
                            587-9120</a> Health Benefits Office</p>
                </div>
            </div>
            <div class="col-xs-12  col-sm-4  col-md-4">
                <div class="footerEvents">
                    <p class="footerSocial">
                        <a href="https://www.facebook.com/bapanyc/" target="_blank">
                            <i class="fa fa-facebook-square" aria-hidden="true"></i>
                        </a>
                        <a href="https://twitter.com/NYPD_BAPA" target="_blank">
                            <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        </a>
                        <a href="#" target="_blank"> <i class="fa fa-instagram" aria-hidden="true"></i> </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer><!-- #colophon -->
<div class="footerBottom">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6">

            </div>
            <div class="col-xs-12 col-sm-6">
                <div class="copyright">© 2020 Bangladeshi American Police Association, Inc.</div>
            </div>
        </div>
    </div>
</div>
</div><!-- #page -->






</body>
</html>


<?php $__env->startSection('main'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(__('events.page_title')); ?></h1>
    <p class="mb-4"><?php echo e(__('events.welcome_msg')); ?></p>


    <div align="right">
        <a href="<?php echo e(route('events.index')); ?>" class="btn btn-default">Back</a>
    </div>


    <?php echo e(Form::open([ 'method'  => 'post','class'  => 'col-sm-6','files'=>'true', 'route' => [ 'events.store' ]  ])); ?>


    <?php echo csrf_field(); ?>


    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_title', (Lang::get('events.enter_msg').' '.Lang::get('events.event_title')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_title', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('events.event_title')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_details', (Lang::get('events.enter_msg').' '.Lang::get('events.event_details')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_details', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('events.event_details')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_venue', (Lang::get('events.enter_msg').' '.Lang::get('events.event_venue')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_venue', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('events.event_venue')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_flyer_location', (' Upload '.Lang::get('events.event_flyer_location')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::file('event_flyer_location', array('class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_starting_date', (Lang::get('events.enter_msg').' '.Lang::get('events.event_starting_date')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_starting_date', $value = null ,array('id'=>'datepicker1','class' => 'form-control','placeholder'=>Lang::get('events.event_starting_date')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_starting_time', (Lang::get('events.enter_msg').' '.Lang::get('events.event_starting_time')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_starting_time', $value = null ,array('id'=>'timepicker1','class' => 'form-control','placeholder'=>Lang::get('events.event_starting_time')))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_ending_time', (Lang::get('events.enter_msg').' '.Lang::get('events.event_ending_time')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_ending_time', $value = null ,array('id'=>'timepicker2','class' => 'form-control','placeholder'=>Lang::get('events.event_ending_time')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_ticket_price', (Lang::get('events.enter_msg').' '.Lang::get('events.event_ticket_price')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_ticket_price', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('events.event_ticket_price')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_total_seat', (Lang::get('events.enter_msg').' '.Lang::get('events.event_total_seat')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_total_seat', $value = null ,array('class' => 'form-control','placeholder'=>Lang::get('events.event_total_seat')))); ?>

        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_active', (Lang::get('events.enter_msg').' '.Lang::get('events.event_active')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo Form::select('event_active', $status_items,'Select', ['class' => 'form-control']); ?>

        </div>
    </div>



    <br/>


    <div class="form-group text-center">
        <?php echo e(Form::submit(Lang::get('events.submit_btn_msg'), array('class' => 'btn btn-primary'))); ?>


    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>






<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\columbia_association\resources\views/Event/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main'); ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(__('products.page_title')); ?></h1>
    <p class="mb-4"><?php echo e(__('products.welcome_msg')); ?></p>

    <div align="right">
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success btn-sm"><?php echo e(__('products.create')); ?></a>
    </div>
    <br/>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('products.page_name')); ?></h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th><?php echo e(__('products.product_name')); ?></th>
                            <th><?php echo e(__('products.product_description')); ?></th>
                            <th><?php echo e(__('products.price')); ?></th>
                            <th><?php echo e(__('products.stock')); ?></th>
                            <th><?php echo e(__('products.photo')); ?></th>

                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th><?php echo e(__('products.product_name')); ?></th>
                            <th><?php echo e(__('products.product_description')); ?></th>
                            <th><?php echo e(__('products.price')); ?></th>
                            <th><?php echo e(__('products.stock')); ?></th>
                            <th><?php echo e(__('products.photo')); ?></th>

                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($row->product_name); ?></td>
                                <td><?php echo e($row->product_description); ?></td>
                                <td><?php echo e($row->price); ?></td>
                                <td><?php echo e($row->stock); ?></td>
                                <td><img width="50" src="<?php echo e(asset('public/images/product/'.$row->photo)); ?>"></td>


                                <td class="text-center">
                                    <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'products.destroy', $row->id ] ])); ?>


                                    <a href="<?php echo e(route('products.show', $row->id)); ?>" class="btn btn-primary">Show</a>
                                    <a href="<?php echo e(route('products.edit', $row->id)); ?>" class="btn btn-warning">Edit</a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                            onclick="return confirm('Are you sure you want to delete this item?');"
                                            class="btn btn-danger">Delete
                                    </button>
                                    <?php echo e(Form::close()); ?>


                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->


    <?php echo $data->links(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bapa\resources\views/Product/index.blade.php ENDPATH**/ ?>
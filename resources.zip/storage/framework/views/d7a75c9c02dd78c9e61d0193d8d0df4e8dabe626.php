<section class="homepageBgLead" style="background-image: url(<?php echo e(URL::to('/public/images/front/bg2.jpg')); ?>);">
    <div class="container text-center">
        <!-- <h1>Representing The <span class="largeText">Greatest Detectives</span> <span class="bottomText">In the World</span></h1> -->
        <br/><br/><br/>
        <h1><span class="largeText">Bangladeshi American Police Association</span> <span class="bottomText">@bapanyc    Nonprofit Organization</span>
        </h1>
    </div>
</section><?php /**PATH F:\xampp\htdocs\bapa\resources\views/partials/banner.blade.php ENDPATH**/ ?>
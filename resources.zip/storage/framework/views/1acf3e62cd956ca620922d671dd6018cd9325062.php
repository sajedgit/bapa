

<?php $__env->startSection('main'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(__('events.page_title')); ?></h1>
    <p class="mb-4"><?php echo e(__('events.welcome_msg')); ?></p>

    <div align="right">
        <a href="<?php echo e(route('events.index')); ?>" class="btn btn-default">Back</a>
    </div>
    <br/>


    <?php echo e(Form::open([ 'method'  => 'post','class'  => 'col-sm-6','files'=>'true', 'route' => [ 'events.update', $data->id ] ])); ?>


    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>



    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_title', (Lang::get('events.edit_msg').' '.Lang::get('events.event_title')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_title', $value = $data->event_title ,array('class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_details', (Lang::get('events.edit_msg').' '.Lang::get('events.event_details')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_details', $value = $data->event_details ,array('class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_venue', (Lang::get('events.edit_msg').' '.Lang::get('events.event_venue')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_venue', $value = $data->event_venue ,array('class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_flyer_location', (' Update '.Lang::get('events.event_flyer_location')),array('class'=>'control-label'))); ?>

        </div>

        <div class="col-sm-8">
            <?php echo e(Form::file('event_flyer_location', array('class' => 'form-control'))); ?>

            <img src="<?php echo e(URL::to('/')); ?>/public/images/<?php echo e($data->event_flyer_location); ?>" class="img-thumbnail" width="100"/>
            <input type="hidden" name="hidden_image" value="<?php echo e($data->event_flyer_location); ?>"/>

        </div>
    </div>



    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_starting_date', (Lang::get('events.edit_msg').' '.Lang::get('events.event_starting_date')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_starting_date', $value = $data->event_starting_date ,array('id'=>'datepicker1','class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_starting_time', (Lang::get('events.edit_msg').' '.Lang::get('events.event_starting_time')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_starting_time', $value = $data->event_starting_time ,array('id'=>'timepicker1','class' => 'form-control'))); ?>

        </div>
    </div>


    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_ending_time', (Lang::get('events.edit_msg').' '.Lang::get('events.event_ending_time')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_ending_time', $value = $data->event_ending_time ,array('id'=>'timepicker2','class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_ticket_price', (Lang::get('events.edit_msg').' '.Lang::get('events.event_ticket_price')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_ticket_price', $value = $data->event_ticket_price ,array('class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_ticket_price_children', (Lang::get('events.edit_msg').' '.Lang::get('events.event_ticket_price_children')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_ticket_price_children', $value = $data->event_ticket_price_children ,array('class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_total_seat', (Lang::get('events.edit_msg').' '.Lang::get('events.event_total_seat')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::text('event_total_seat', $value = $data->event_total_seat ,array('class' => 'form-control'))); ?>

        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('event_active', (Lang::get('events.edit_msg').' '.Lang::get('events.event_active')),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo Form::select('event_active', $status_items,$data->event_active, ['class' => 'form-control']); ?>

        </div>
    </div>





    <br/>



    <div class="form-group">
        <label class="control-label ">&nbsp;&nbsp;</label>
        <?php echo e(Form::submit(Lang::get('events.update_btn_msg'), array('class' => 'btn btn-primary'))); ?>

    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bapa\resources\views/Event/edit.blade.php ENDPATH**/ ?>
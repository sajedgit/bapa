

<?php $__env->startSection('main'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(__('messages.page_title')); ?></h1>
    <p class="mb-4"><?php echo e(__('messages.welcome_msg')); ?></p>

    <div align="right">
        <a href="<?php echo e(route('messages.index')); ?>" class="btn btn-default">Back</a>
    </div>
    <br/>


    <?php echo e(Form::open([ 'method'  => 'post','class'  => 'col-sm-6', 'route' => [ 'messages_update' ] ])); ?>


    <?php echo csrf_field(); ?>



    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('title', (' Title '),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::textArea('title', $value = $data->title ,array('class' => 'form-control'))); ?>

        </div>
    </div>


    <div class="form-group row">
        <input type="hidden" name="table_name" value="<?php echo $table; ?>">
        <input type="hidden" name="url" value="<?php echo $url; ?>">
    </div>

    <div class="form-group row">
        <div class="col-sm-4 mb-3 mb-sm-0">
            <?php echo e(Form::label('description', (' Message '),array('class'=>'control-label'))); ?>

        </div>
        <div class="col-sm-8">
            <?php echo e(Form::textArea('description', $value = $data->description ,array('class' => 'form-control'))); ?>

        </div>
    </div>




    <br/>



    <div class="form-group text-center">
        <label class="control-label ">&nbsp;&nbsp;</label>
        <?php echo e(Form::submit(Lang::get('messages.update_btn_msg'), array('class' => 'btn btn-primary'))); ?>

    </div>



    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bapa\resources\views/Message/edit_p_vp_gs.blade.php ENDPATH**/ ?>
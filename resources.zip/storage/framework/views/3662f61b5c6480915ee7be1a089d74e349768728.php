

<?php $__env->startSection('main'); ?>

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800"><?php echo e(__('events.page_title')); ?></h1>
<p class="mb-4"><?php echo e(__('events.welcome_msg')); ?></p>


 <div align="right">
  <a href="<?php echo e(route('events.index')); ?>" class="btn btn-default">Back</a>
 </div>
 <br />

 <table class="table table-striped">
        <thead >
        <tr class="info">

            <th scope="col">Column</th>
            <th scope="col">Value</th>
        </tr>
        </thead>
        <tbody>
		<tr>
			<td><?php echo e(__('events.event_title')); ?>

 			<td><?php echo e($data->event_title); ?> </td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_details')); ?>

 			<td><?php echo e($data->event_details); ?> </td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_venue')); ?>

 			<td><?php echo e($data->event_venue); ?> </td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_flyer_location')); ?>

            <td><img   src="<?php echo e(URL::to('/')); ?>/public/images/<?php echo e($data->event_flyer_location); ?>"></td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_flyer_type')); ?>

 			<td><?php echo e($data->event_flyer_type); ?> </td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_starting_date')); ?>

 			<td><?php echo e($data->event_starting_date); ?> </td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_starting_time')); ?>

 			<td><?php echo e($data->event_starting_time); ?> </td>

		</tr>

		<tr>
			<td><?php echo e(__('events.event_ending_time')); ?>

 			<td><?php echo e($data->event_ending_time); ?> </td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_ticket_price')); ?>

 			<td><?php echo e($data->event_ticket_price); ?> </td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_total_seat')); ?>

 			<td><?php echo e($data->event_total_seat); ?> </td>

		</tr>
		<tr>
			<td><?php echo e(__('events.event_active')); ?>

 			<td><?php echo e($data->event_active); ?> </td>

		</tr>

		</tbody>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bapa\resources\views/Event/view.blade.php ENDPATH**/ ?>